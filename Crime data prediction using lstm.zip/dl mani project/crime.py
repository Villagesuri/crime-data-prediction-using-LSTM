import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.metrics import mean_squared_error
# Load the dataset
data = pd.read_csv('/content/crime_data.csv', parse_dates=['name'], index_col='name')
# Check if the data loaded correctly and the date is parsed
print(data.head())
# Visualize the data (using 'Rape' column for visualization)
plt.figure(figsize=(10, 6))
plt.plot(data['Rape'])
plt.title('Rape Cases Over Time')
plt.xlabel('Date')
plt.ylabel('Number of Rape Cases')
plt.show()
# Preprocess the data (we will use 'Rape' column for prediction)
crime_data = data['Rape'].values.reshape(-1, 1)
# Scale the data to the range (0, 1)
scaler = MinMaxScaler(feature_range=(0, 1))
crime_data_scaled = scaler.fit_transform(crime_data)
# Create dataset for LSTM (using previous 30 days to predict the next)
def create_dataset(data, time_step=1):
X, y = [], []
    for i in range(len(data) - time_step):
        X.append(data[i:(i + time_step), 0])
        y.append(data[i + time_step, 0])
        return np.array(X), np.array(y)
    time_step = 30
    X, y = create_dataset(crime_data_scaled, time_step)
    X = X.reshape(X.shape[0], X.shape[1], 1)
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)
# Build the LSTM model
model = Sequential()
model.add(LSTM(units=50,return_sequences=False,input_shape=(X_train.shape[1], 1)))model.add(Dense(units=1))
model.compile(optimizer='adam', loss='mean_squared_error')
# Train the model
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))
# Make predictions
predictions = model.predict(X_test)
# Inverse transform predictions and actual values to original scale
predictions = scaler.inverse_transform(predictions)
y_test_actual = scaler.inverse_transform(y_test.reshape(-1, 1))
# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(y_test_actual, color='blue', label='Actual Rape Cases')
plt.plot(predictions, color='red', label='Predicted Rape Cases')
plt.title('Rape Case Prediction')
plt.xlabel('Time')
plt.ylabel('Number of Rape Cases')
plt.legend()
plt.show()
# Calculate Mean Squared Error
mse = mean_squared_error(y_test_actual, predictions)
print(f'Mean Squared Error: {mse}')